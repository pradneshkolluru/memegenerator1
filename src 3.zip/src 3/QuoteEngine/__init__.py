"""file for referencing modules within QuoteEngine."""
from QuoteEngine.DOCXImport import DocxIngestor
from QuoteEngine.PDFImport import PDFIngestor
from QuoteEngine.TXTImport import TextIngestor
from QuoteEngine.CSVImport import CSVIngestor
from QuoteEngine.IngesterInterface import IngestorInterface
from QuoteEngine.Ingestor import Ingestor
from QuoteEngine.QuoteModel import QuoteModel
