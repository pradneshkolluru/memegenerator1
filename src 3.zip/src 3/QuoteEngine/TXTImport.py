"""Pull data from txt files."""
from QuoteEngine.IngesterInterface import IngestorInterface
from QuoteEngine.QuoteModel import QuoteModel

from typing import List


class TextIngestor(IngestorInterface):
    """Generate Quotes from txt File."""

    def __init__(self):
        """Reassign superclass enabled_extensions variable."""
        IngestorInterface.enabled_extensions = ['txt']

    @classmethod
    def parse(cls, path: str) -> List[QuoteModel]:
        """Check if filetype is valid, returns list of Quote Mode objects."""
        if not IngestorInterface.can_ingest(path):
            raise Exception('Invalid txt File Type')

        content = []
        with open(path, 'r', encoding='utf-8-sig') as f:
            for lines in f:
                line_edit = lines.strip('\n')
                split = line_edit.split(" - ")
                content.append(QuoteModel(split[0], split[1]))
        return(content)
