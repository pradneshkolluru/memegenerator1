"""Pull data from docx files."""
from QuoteEngine.IngesterInterface import IngestorInterface
from QuoteEngine.QuoteModel import QuoteModel

import docx
from typing import List


class DocxIngestor(IngestorInterface):
    """Generate Quotes from DOCX File."""

    def __init__(self):
        """Reassign superclass enabled_extensions variable."""
        IngestorInterface.enabled_extensions = ['docx']

    @classmethod
    def parse(cls, path: str) -> List[QuoteModel]:
        """Check if filetype is valid, returns list of Quote Mode objects."""
        if not IngestorInterface.can_ingest(path):
            raise Exception('Invalid docx File Type')

        content = []

        document = docx.Document(path)

        for x in document.paragraphs:
            if x.text == "":
                continue
            text = x.text
            text_split = text.split('-')
            text_list = []
            for i in text_split:
                text_list.append(i.strip(" ",))
            text_list = [i.strip('"') for i in text_list]
            content.append(QuoteModel(text_list[0], text_list[1]))
        return(content)
