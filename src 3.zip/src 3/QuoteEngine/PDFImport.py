"""Pull data from pdf files."""
from QuoteEngine.IngesterInterface import IngestorInterface
from QuoteEngine.QuoteModel import QuoteModel

from typing import List
import subprocess
import random
import os


class PDFIngestor(IngestorInterface):
    """Generate Quotes from DOCX File."""

    def __init__(self):
        """Reassign superclass enabled_extensions variable."""
        IngestorInterface.enabled_extensions = ['pdf']

    @classmethod
    def parse(cls, path: str) -> List[QuoteModel]:
        """Check if filetype is valid, returns list of Quote Mode objects."""
        if not IngestorInterface.can_ingest(path):
            raise Exception('Invalid pdf File Type')

        content = []
        tmp = f'QuoteEngine/temp_{random.randint(0,1000000)}.txt'

        call = subprocess.call(['pdftotext', path, tmp])
        with open(tmp, 'r', encoding='utf-8-sig') as f:
            text = (f.readlines(1))[0]
            split = text.split(' "')
            for i in split:
                string = i.replace("\n", "")
                split = string.split(' - ')
                split = [i.strip('"') for i in split]
                content.append(QuoteModel(split[0], split[1]))
        os.remove(tmp)
        return(content)
