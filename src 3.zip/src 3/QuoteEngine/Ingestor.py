"""
Integrate all Ingestor Models.

Able to pass in any file path and Ingestor will be able to determine file type
and will pull data.
"""
from QuoteEngine.IngesterInterface import IngestorInterface
from QuoteEngine.QuoteModel import QuoteModel
from QuoteEngine.PDFImport import PDFIngestor
from QuoteEngine.TXTImport import TextIngestor
from QuoteEngine.CSVImport import CSVIngestor
from QuoteEngine.DOCXImport import DocxIngestor

from typing import List


class Ingestor(IngestorInterface):
    """Based on filetype, utilize correct pipeline to return Quote Models."""

    ingestors = [TextIngestor, PDFIngestor, DocxIngestor, CSVIngestor]

    @classmethod
    def parse(cls, path: str) -> List[QuoteModel]:
        """Iterate through ingestors, once correct return Quote Model."""
        for i in cls.ingestors:
            x = i()
            if x.can_ingest(path):
                return(x.parse(path))
