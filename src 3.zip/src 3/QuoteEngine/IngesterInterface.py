"""
This is the base class script for the Quote Engine.

This contains the Ingestor Interface class checks whether a given file is
compatable with the generator and then proceeds to make the abstract parse
method.
"""
from abc import ABC, abstractmethod
from QuoteEngine.QuoteModel import QuoteModel

from typing import List


class IngestorInterface(ABC):
    """Base class for ingestor classes.

    creates abstract class for parsing file content and checks fr compatabiity.
    """

    enabled_extensions = []

    @classmethod
    def can_ingest(cls, path: str) -> bool:
        """Check whether input file can be parsed by the chosen Ingestor."""
        file_type = path.split('.')[-1]
        return file_type in cls.enabled_extensions

    @abstractmethod
    def parse(cls, path: str) -> List[QuoteModel]:
        """Create abstract class for child classes to parse file content."""
        pass
