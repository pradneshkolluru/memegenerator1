"""Format Data Pulled from various file types."""


class QuoteModel:
    """Processed author name and quote content and package into object."""

    def __init__(self, body, author):
        """Take in body and author arguements and makes class object."""
        self.body = body
        self.author = author

    def __repr__(self):
        """Return computer legible string."""
        return "{body}, {name}".format(body=self.body,
                                       name=self.author)
