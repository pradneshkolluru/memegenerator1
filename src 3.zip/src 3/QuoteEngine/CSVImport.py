"""Pull data from csv files."""
from QuoteEngine.IngesterInterface import IngestorInterface
from QuoteEngine.QuoteModel import QuoteModel

import pandas as pd
from typing import List


class CSVIngestor(IngestorInterface):
    """Generate Quotes from CSV File."""

    def __init__(self):
        """Reassign superclass enabled_extensions variable."""
        IngestorInterface.enabled_extensions = ['csv']

    @classmethod
    def parse(cls, path: str) -> List[QuoteModel]:
        """Check if filetype is valid, returns list of Quote Mode objects."""
        if not IngestorInterface.can_ingest(path):
            raise Exception('Invalid CSV File Type')

        content = []
        quote_df = pd.read_csv(path)
        for index, row in quote_df.iterrows():
            content.append(QuoteModel(row['body'], row['author']))
        return(content)
