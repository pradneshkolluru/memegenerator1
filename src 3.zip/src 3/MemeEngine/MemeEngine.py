"""Generate Meme from image, body, and author."""
from PIL import Image, ImageDraw
import random
import os
import pandas as pd


class MemeEngine:
    """Take in output director and meme contents to generate meme."""

    def __init__(self, output_dir):
        """Find or create provided output directory."""
        self.output_dir = output_dir

        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

    def make_meme(self, img_path, text=None, author=None,
                  width=200, save_name=None) -> str:
        """Generate meme from path, content, and size, return out-path."""
        img = Image.open(img_path)
        if width is not None:
            ratio = width / float(img.size[0])
            height = int(ratio * float(img.size[1]))
            img = img.resize((width, height), Image.NEAREST)

        if text and author is not None:
            start_position_x = random.randrange(0, img.size[0] - 75)
            start_position_y = random.randrange(0, img.size[1] - 50)
            draw = ImageDraw.Draw(img)
            draw.text((start_position_x, start_position_y), text, fill='white')
            draw.text((start_position_x + 50, start_position_y + 20),
                      author, fill='white')

        if save_name is not None:
            outfile = self.output_dir + '/' + save_name + '.jpeg'
            img.save(outfile)
        else:
            df = pd.read_csv('MemeEngine/counter.csv')
            num = int(df['counter'].iloc[0])
            outfile = self.output_dir + '/' + 'Temp' + str(num) + '.jpeg'
            img.save(outfile)
            df['counter'] = num + 1
            df.to_csv('MemeEngine/counter.csv')

        return outfile
