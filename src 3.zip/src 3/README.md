# **UDACITY Meme Generator Application**

Through completing the learning modules for the UDACITY Intermediate Python course, I have learned to put together this meme generator app as a capstone project.

##### Overview

This application enables the user to provide an image, author, and body paragraph for meme generation. The file containing the body and author is sent to Ingestor Module for parsing by the appropriate file ingestor. The MemeEngine module then opens an image based on a give path and overlays the meme content onto it. The meme.py script enables users to make memes directly from the command line interface, whereas the app.py application enables the user to create a meme using a web interface.

##### Set up and run program
Download all the files within this project directory. Then refer to the requirements.txt file to pip install all the dependancies that are needed. Once this is done, you are ready to run the application. To start making memes directly from the commandline, navigate to the main root directory and run python3 meme.py. Use the --help arguement to see what commands are needed in order to generate you customized meme. For reference, the arg parser takes in --path, --body, --author, and --name to generate your meme. You can also generate memes from the web interface. To do this first open commandline. Then navigate to the root project directory and run python3 app.py. This command should return a url that you can copy and past into the browser, revealing the web interface. Through this web interface you can generate your own random memes or make custom ones through providing an image url, body, and author

##### Modules and Dependancies Description

The following are a list of dependancies and modules that are needed to run the program

###### import sys

Used for arg parser at Command Line Interface to generate memes through meme.py application.


###### import random

Helps to generate random images and quotes for meme generations. Additional'y helps to create random temporary files.

###### import subprocess

Helps us to make use of pdftotext pipeline from python file inorder to parse pdf files.

###### import requests

Generates web requests to retrieve images from web url.

###### import pandas

Used to work with .csv files:

###### import docx

Used to parse word document files

#### Meme Creation Modules

###### _data --> 

folder that contains all the built in quotes and images

###### QuoteEngine : 

Parse contents of docx, pdf, csv, and txt files to get structured elements of body and author information

###### MemeEngine :

makes use imported libraries to generate a meme from an image, body, and author


###### app.py : 

Generates meme generator web interface using flask

###### meme.py : enables users to generate memes from command line interface

